jmeter-jdbc-sqllite-example
===========================

JMeter JDBC SqlLite Example

running
--------------

To run this, you need to put the included .jar JDBC driver in your JMeter lib 
folder and restart JMeter.  Then, open this project and try it out!
